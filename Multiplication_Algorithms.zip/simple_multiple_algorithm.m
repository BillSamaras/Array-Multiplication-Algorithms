%Algorithm for multiple arrays
function main()
average1=0;
average2=0;
theoretical_simple=[64, 512, 4096, 32768, 262144, 2097152, 16777216, 134217728, 1073741824];
theoretical_strassen=[26.9460, 139.8755, 726.0876, 3769.0886, 19565.1696, 101561.9165, 527203.3455, 2736688.8784, 14206029.0024];
N=4;
j=1;
while N < 1025
    for i=1:10
        A = randn(N);
        B = randn(N);
        
        tic
        [C]=simple_algorithm(A,B,N);     
        average1=average1+toc;
        
        tic
        [D] = strassen(A,B,8);     
        average2=average2+toc;
    end
     
    average_simple(j)=average1/10;
    average_strassen(j)=average2/10;
    inputs(j) = N;
    average1=0;
    average2=0;
    N = 2.^(j+2);
    j = j + 1;
end
figure
subplot(211);
plot(inputs,theoretical_simple,'-*',inputs,theoretical_strassen,'r-*');
title('Theoretical Analysis')
grid on;
subplot(212);
plot(inputs,average_simple,'-*',inputs,average_strassen,'r-*');
title('Run-time Analysis') 
grid on;
end

function [C]=simple_algorithm(A,B,N)
for i = 1:N
    for j = 1:N
        s = 0;
        for k = 1:N
            s = s + A(i,k) * B(k,j);
        end
        C(i,j) = s;
    end
end
end

function C = strassen(A, B, nmin)

if nargin < 3, nmin = 8; end

n = length(A);

if n <= nmin  
   C = A*B;
else
   m = n/2; i = 1:m; j = m+1:n;
   P1 = strassen( A(i,i)+A(j,j), B(i,i)+B(j,j), nmin);
   P2 = strassen( A(j,i)+A(j,j), B(i,i), nmin);
   P3 = strassen( A(i,i), B(i,j)-B(j,j), nmin);
   P4 = strassen( A(j,j), B(j,i)-B(i,i), nmin);
   P5 = strassen( A(i,i)+A(i,j), B(j,j), nmin);
   P6 = strassen( A(j,i)-A(i,i), B(i,i)+B(i,j), nmin);
   P7 = strassen( A(i,j)-A(j,j), B(j,i)+B(j,j), nmin);
   C = [ P1+P4-P5+P7  P3+P5;  P2+P4  P1+P3-P2+P6 ];
end
end


